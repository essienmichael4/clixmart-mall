import { PageOptionsDto } from "./pageOptions.dto";

export interface PageMetaDtoParamenters {
    pageOptionsDto: PageOptionsDto,
    itemCount: number
}
